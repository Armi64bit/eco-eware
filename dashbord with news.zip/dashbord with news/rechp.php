<?php
$connect = mysqli_connect("localhost", "root", "", "ecoaware");
$output = '';
if(isset($_POST["query"]))
{
	$search = mysqli_real_escape_string($connect, $_POST["query"]);
	$query = "
	SELECT * FROM article 
	WHERE IdActualite LIKE '%".$search."%'
	OR TitreActualite LIKE '%".$search."%' 
	OR DateActualite LIKE '%".$search."%' 
	OR DescriptionActualite LIKE '%".$search."%' 
	OR ImageActualite LIKE '%".$search."%'
	";
}
else
{
	$query = "
	SELECT * FROM article ORDER BY IdActualite";
}
$result = mysqli_query($connect, $query);
if(mysqli_num_rows($result) > 0)
{
	$output .= '<div class="table-responsive">
					<table class="table table bordered">
						<tr>
							<th>IdActualite</th>
							<th>TitreActualite</th>
							<th>DateActualite</th>
							<th>DescriptionActualite</th>
							<th>ImageActualite</th>
						</tr>';
	while($row = mysqli_fetch_array($result))
	{
		$output .= '
			<tr>
				<td>'.$row["IdActualite"].'</td>
				<td>'.$row["TitreActualite"].'</td>
				<td>'.$row["DateActualite"].'</td>
				<td>'.$row["DescriptionActualite"].'</td> 
				<td>'.$row["ImageActualite"].'</td> 
			</tr>
		';
	}
	echo $output;
}
else
{
	echo 'Data Not Found';
}
?>